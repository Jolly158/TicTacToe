/* This is the Driver class for the Tic Tacc Toe game
 * Name:    Scott Jolly
 * Class:   Computer Science II
 * Section 01
 * Activity #5
*/

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class TicTacToe
{
   public static void main(String[] args)
   {
     new Gameboard();
     
   }
}