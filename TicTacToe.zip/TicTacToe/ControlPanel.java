/* This class is the Control Panel for the Tic Tac Toe game. After a game completes, it gives the User the option to Play Again or to Quit.
 * Name:    Scott Jolly
 * Class:   Computer Science II
 * Section 01
 * Activity #5
*/
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class ControlPanel extends JFrame implements ActionListener
{
   private JPanel panel; // Panel
   private JButton quit; // Quit Button
   private JButton newgame; //New Game Button
   public JFrame frame = new JFrame();
   
      public ControlPanel()
      {
          
          setTitle("TTT Control Panel"); // Title
          buildPanel();
          setVisible(true); // Visible
          setSize(310,400);
          
      }
      
      
      public void buildPanel()
      {
          panel = new JPanel(); // Panle
          add(panel);
          quit = new JButton("Quit"); // Initialize Quit Button
          quit.addActionListener(new Quit()); // Add ActionListener to Quit Buttons
          panel.add(quit); // Add Quit button to Panel
          
          newgame = new JButton("New Game"); // Initialize New Game Button
          newgame.addActionListener(this); // Add actionListener to new Game Button
          panel.add(newgame); // Add New Game Button to Panel
      }
      
      //Action Listener for the New game button
      public void actionPerformed(ActionEvent e)
   {
      setVisible(false); // Not visible
      new Gameboard(); // Start new game
      return;
     
   }

 
 
 }
 
  // ActionListener for the Quit Button
 class Quit implements ActionListener
 {
   public void actionPerformed(ActionEvent e)
   {
      System.exit(0); // End/exit
   }
 }