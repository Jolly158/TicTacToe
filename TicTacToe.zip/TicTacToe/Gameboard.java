
/* This class create a Tic Tac Toe GameBoard GUI that the User interacts with to play an AI in Tic Tac Toe
 * Name:    Scott Jolly
 * Class:   Computer Science II
 * Section 01
 * Activity #5
*/


import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.Random;

public class Gameboard extends JFrame implements ActionListener
{
   private JPanel panel; // Panel
   private JButton[] buttons = new JButton[9]; // array of 9 buttons needed for Game
   private JLabel label;
   private JFrame frame = new JFrame();
   
   public Gameboard()
   {
      setTitle("TicTacToe"); //Set's Title of Window
      buildPanel();
      setVisible(true); // GUI is visoble
       setSize(310,310); // Size of Window

   }
   
   
   // This method builds the Panel/Gameboard
   
   
      public void buildPanel()
   {
      setLayout(new GridLayout(3,3));
      buttonLayout();
   }
   
   public void buttonLayout()
   {
   for(int i = 0; i < buttons.length; i++)
     {buttons[i] = new JButton();
      buttons[i].setText(" ");
      buttons[i].addActionListener(this);
      add(buttons[i]);
      }
      
      
   }
   
   // Action Performed when User clicks a button
  public void actionPerformed(ActionEvent e)
    {
   
        JButton source = (JButton)e.getSource();
    
        source.setText("X"); // Sets Player's cgoice as X
        
        //Checks if Player wins the game
        if(checkForWin() == true) 
         {  
            JOptionPane.showMessageDialog(null, "Congrats! You Win");
            new ControlPanel(); // Brings up Control Panel
            setVisible(false);
            return;
         }
       
        
       cpuTurn(); // Calls cpuTurn method
       
       
       //Checks if CPU wins game
       if(checkForWin() == true)
       {
         JOptionPane.showMessageDialog(null, "You Lose!");
         new ControlPanel();
         setVisible(false);
         return;
         
         
       }
       
        
              
       checkFullP(); // Calls checkFullP method  
  }
    
  //This method checks if the player of CPu won the game with their most previous move. This method uses the checkAdjacent method to check for Winning moves.
/* 0|1|2
   3|4|5    The GameBoard is referenced as such
   6|7|8*/
  
   public boolean checkForWin()
   {
      //Horozontal Win Check
      
      if(checkAdjacent(0,1) == true && checkAdjacent(1,2)== true)
         return true;
      
      else if(checkAdjacent(3,4) == true && checkAdjacent(4,5) == true)
         return true;
         
      else if(checkAdjacent(6,7) == true && checkAdjacent(7,8) == true)
         return true;
         
         //Vertical Win Check
         
      else if(checkAdjacent(0,3) == true && checkAdjacent(3,6) == true)
         return true;
         
      else if(checkAdjacent(1,4) == true && checkAdjacent(4,7) == true)
         return true;
         
      else if(checkAdjacent(2,5) == true && checkAdjacent(5,8) == true)
         return true;
         
         //Diagonal Win Check
      
      else if(checkAdjacent(0,4) == true && checkAdjacent(4,8) == true)
         return true;
         
      else if(checkAdjacent(2,4) == true && checkAdjacent(4,6) == true)
         return true;
         
      else return false;
      
   }
   
   // This method checks if their is 2 spots adjacent to eachother that can lead to a win for the CPU
   public boolean checkAdjacent(int a, int b)
   {
      if( buttons[a].getText().equals(buttons[b].getText()) && !buttons[a].getText().equals(" "))
         return true;
      else
         return false;
   }
   
   
      

    // This method uses the checkAdjacent method to check for Winning move for the CPU

   public void cpuTurn()
   {
      
     
      //Horozontal First Row 
      
      if(checkAdjacent(0,1) == true && buttons[2].getText().equals(" "))
         {
           
               buttons[2].setText("O");
             
         }
       else if(checkAdjacent(1,2) == true && buttons[0].getText().equals(" "))
       {
        
            buttons[0].setText("O");
       }
       else if(checkAdjacent(0,2) == true && buttons[0].getText().equals(" "))
       {
     
            buttons[1].setText("O");
       }
      
      // Horozontal Second Row
      else if(checkAdjacent(3,4) == true && buttons[5].getText().equals(" "))
         {
            
               buttons[5].setText("O");
             
         }
      else if(checkAdjacent(4,5) == true && buttons[3].getText().equals(" "))
         {
        
               buttons[3].setText("O");
           
         } 
      else if(checkAdjacent(3,5) == true && buttons[4].getText().equals(" "))
         {
       
               buttons[4].setText("O");
         }
         
         //Horozontal Check Third Row
      else if(checkAdjacent(6,7) == true && buttons[8].getText().equals(" "))
         {
            
             buttons[8].setText("O");
             
         }
      else if(checkAdjacent(7,8) == true && buttons[6].getText().equals(" "))
         {
           
               buttons[6].setText("O");
         }
      else if(checkAdjacent(6,8) == true && buttons[8].getText().equals(" "))
         {
            
               buttons[7].setText("O");
         }
         
         
         

      
      //Vertical First Column   
      
      else if(checkAdjacent(0,3) == true && buttons[6].getText().equals(" "))
         {
           
             buttons[6].setText("O");
             
         }
      else if(checkAdjacent(3,6) == true && buttons[0].getText().equals(" "))
         {
           
               buttons[0].setText("O");
         }
      else if(checkAdjacent(0,6) == true && buttons[3].getText().equals(" "))
         {
            
               buttons[3].setText("O");
         }

      // Vertical Second Column
         
      else if(checkAdjacent(1,4) == true && buttons[7].getText().equals(" "))
         {
           
             buttons[7].setText("O");
             
         }
      else if(checkAdjacent(4,7) == true && buttons[1].getText().equals(" "))
         {
            
               buttons[1].setText("O");
         }
      else if(checkAdjacent(1,7) == true && buttons[4].getText().equals(" "))
         {
           
               buttons[4].setText("O");
         }

      
      //Vertical Third Column
      
      else if(checkAdjacent(2,5) == true && buttons[8].getText().equals(" "))
         {
            
             buttons[8].setText("O");
             
         }
      else if(checkAdjacent(5,8) == true && buttons[2].getText().equals(" "))
         {
           
               buttons[2].setText("O");
         }
      else if(checkAdjacent(2,8) == true && buttons[5].getText().equals(" "))
         {
            
               buttons[5].setText("O");
         }

      //Diagonal
         
      else if(checkAdjacent(0,4) == true && buttons[8].getText().equals(" "))
         {
            
             buttons[8].setText("O");
             
         }
      else if(checkAdjacent(4,8) == true && buttons[0].getText().equals(" "))
         {
            
               buttons[0].setText("O");
         }
      else if(checkAdjacent(0,8) == true && buttons[4].getText().equals(" "))
         {
            
               buttons[4].setText("O");
         }

         
      else if(checkAdjacent(2,4) == true && buttons[6].getText().equals(" "))
         {
             
             buttons[6].setText("O");
             
         }
      else if(checkAdjacent(4,6) == true && buttons[2].getText().equals(" "))
         {
            
               buttons[2].setText("O");
         }
      else if(checkAdjacent(2,6) == true && buttons[4].getText().equals(" "))
         {
           
               buttons[4].setText("O");
         }
      
      
      // If no wiing moves are available, cpu will choose random spot
         else selectRandom();
         


         
       
       
    
      
   }
   
// This method chooses a random move for CPU
   
  public void selectRandom()
  {
    Random m = new Random();
    int r = m.nextInt(8);
    
    if(buttons[r].getText().equals(" "))
      buttons[r].setText("O");
    else
     { if(checkFull() == false)
     selectRandom();
      }
      
 
  }
  
  // This method checks if the GameBoard is full
  public boolean checkFull()
  {
   if(!buttons[0].getText().equals(" "))
   {
      if(!buttons[1].getText().equals(" "))
      {
         if(!buttons[2].getText().equals(" "))
         {
           if(!buttons[3].getText().equals(" "))
           {
            if(!buttons[4].getText().equals(" "))
            {
               if(!buttons[5].getText().equals(" "))
               {
                  if(!buttons[6].getText().equals(" "))
                  {
                     if(!buttons[7].getText().equals(" "))
                     {
                        if(!buttons[8].getText().equals(" "))
                        {
                           
                                                   }
                     }
                  }
               }
            }
           }
         }
      }
   }
    return true;
  }
  
  
  // This method is simlar to checkFull, but is void rather than boolean and checks for a tie
   public void checkFullP()
  {
   if(!buttons[0].getText().equals(" "))
   {
      if(!buttons[1].getText().equals(" "))
      {
         if(!buttons[2].getText().equals(" "))
         {
           if(!buttons[3].getText().equals(" "))
           {
            if(!buttons[4].getText().equals(" "))
            {
               if(!buttons[5].getText().equals(" "))
               {
                  if(!buttons[6].getText().equals(" "))
                  {
                     if(!buttons[7].getText().equals(" "))
                     {
                        if(!buttons[8].getText().equals(" "))
                        {
                          JOptionPane.showMessageDialog(null, "It's a Tie");
                          setVisible(false);
                          new ControlPanel();
                          
                           
                        }
                     }
                  }
               }
            }
           }
         }
      }
   }
    
  }

 
    

}